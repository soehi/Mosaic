$ErrorActionPreference = 'SilentlyContinue'
$log = 'C:\Users\Public\MosaicQA2856\logs\2856-browse.log'
Remove-Item $log -Force
$p = Start-Process msiexec -ArgumentList '/i','D:\Code\Mosaic\artifacts\installer\Mosaic-0.17.6-win-x64.msi','/L*V',$log -PassThru
Start-Sleep 8
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms
$win = Get-Process | Where-Object { $_.MainWindowTitle -match 'Mosaic' } | Sort-Object StartTime -Descending | Select-Object -First 1
[Microsoft.VisualBasic.Interaction]::AppActivate($win.Id)
Start-Sleep -Milliseconds 800
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}')   # FreshStart -> Location
Start-Sleep 2
$win = Get-Process | Where-Object { $_.MainWindowTitle -match 'Mosaic' } | Sort-Object StartTime -Descending | Select-Object -First 1
[Microsoft.VisualBasic.Interaction]::AppActivate($win.Id)
Start-Sleep -Milliseconds 500
[System.Windows.Forms.SendKeys]::SendWait('%b')        # Alt+B -> Browse...
Write-Output 'browse opened'
